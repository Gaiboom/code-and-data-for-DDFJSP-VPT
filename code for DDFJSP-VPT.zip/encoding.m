function individual=encoding(G1)
G1=sortrows(G1,3);
operation_assignment=G1(:,2)';
D=size(operation_assignment,2);
G2=sortrows(G1,1);
machine_assignment=G2(:,5)';
job_set=unique(G2(:,2));
Njob=size(job_set,1);
for i=1:Njob
    job=job_set(i);
    index=find(G2(:,2)==job);
    factory_assignment(1,i)=G2(index(1),6);
end
individual(1:Njob)=factory_assignment;
individual(Njob+1:Njob+D)=machine_assignment;
individual(Njob+D+1:Njob+2*D)=operation_assignment;
end