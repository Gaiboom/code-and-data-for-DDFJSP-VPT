function P = updateNeighbor( lamda,z,P,Bi,off,zmin )
global N M  D ct Pc Pm Njob
%���������
for i=1:length(Bi)
    gte_xi=tchebycheff_approach(lamda,z,P(Bi(i),Njob+2*D+1:Njob+2*D+M),Bi(i));
    gte_off=tchebycheff_approach(lamda,z,off(:,Njob+2*D+1:Njob+2*D+M),Bi(i));
%     gte_xi=ws_approach(lamda,X(Bi(i),(x_num+1):(x_num+f_num)),Bi(i));
%     gte_off=ws_approach(lamda,off(:,(x_num+1):(x_num+f_num)),Bi(i));
    if gte_off <= gte_xi
        P(Bi(i),:)=off;
    end
end

