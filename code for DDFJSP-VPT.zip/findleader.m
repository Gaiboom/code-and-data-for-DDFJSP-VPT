function [alpha,peta,sita]=findleader(P1)
global D M Njob
max_rank=max(P1(:,Njob+2*D+M+1));
rank_1=P1(P1(:,Njob+2*D+M+1)==1,:);

% if max_rank==1 || size(rank_1,1)>2
%      rank_1 = sortrows( rank_1, Njob+2*D+M+1, 'descend');
%      alpha=rank_1 (1,:);
%      peta=rank_1 (2,:);
%      sita=rank_1 (3,:);
if size(rank_1,1)==1
    alpha=rank_1;
    rank_2=P1(P1(:,Njob+2*D+M+1)==2,:);
    if size(rank_2,1)==1
        peta=rank_2;
        rank_3=P1(P1(:,Njob+2*D+M+1)==3,:);
       rank_3 = sortrows( rank_3, -(Njob+2*D+M+2));
       sita=rank_3(1,:);
    else
         rank_2 = sortrows( rank_2,  -(Njob+2*D+M+2));
         peta=rank_2(1,:);
         sita=rank_2(2,:);
    end
else
    if  size(rank_1,1)==2
        rank_1 = sortrows( rank_1,  -(Njob+2*D+M+2));
        alpha=rank_1(1,:);
        peta=rank_1(2,:);
        rank_2=P1(P1(:,Njob+2*D+M+1)==2,:);
        rank_2 = sortrows( rank_2,  -(Njob+2*D+M+2));
        sita=rank_2(1,:);
    else
        rank_1 = sortrows( rank_1,  -(Njob+2*D+M+2));
        alpha=rank_1(1,:);
        peta=rank_1(2,:);
        sita=rank_1(3,:);
    end
end
end