% clc;
% clear all��
global DMOGWOPS DMOGWOEvo DMOGWOTime run_counts D0 GG
all_instances=10;%Total number of instances
run=1; %Number of independent runs of the algorithm

t=0; %rescheduling moment
run_counts=0;%Number of rescheduling
Res_flag=0;
for instances=1:all_instances
    Res_flag=0;
    initialPara(instances);

    run_counts=run_counts+1;
    individual0=StaticScheduling(instances,run);
    GG=zeros(D0,14);
      individual=importdata(sprintf('individual0_%d.mat', instances));
    while Res_flag~=3
        [Res_flag,t,new_individual]=findResPoint(individual,t,instances);
        individual=new_individual;
        if Res_flag==1
            run_counts=run_counts+1;
             individual=DynamicScheduling(instances,run,t);
        end
    end
end