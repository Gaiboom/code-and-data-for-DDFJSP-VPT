function individual=MOHGWORecombination(P)
global N M D Njob PM ct
Parent_population=P;
individual=zeros(N,D*2+Njob+M+4);
Parent_highest_rank=max(Parent_population(:,D*2+Njob+M+1));

alpha_pack = Parent_population(Parent_population(:,D*2+Njob+M+1) == 1, :); %1��  ����һ�� ����Ϊ�쵼��Ⱥ   2������Ϊ���� ǰ������Ϊ�쵼��Ⱥ 3��% ������������ ǰ���㶼��Ϊ�쵼��Ⱥ
if Parent_highest_rank >= 2 
    peta_pack = Parent_population(Parent_population(:,D*2+Njob+M+1) == 2, :);
else
    peta_pack = [];
end
if Parent_highest_rank >= 3 
    sita_pack = Parent_population(Parent_population(:,D*2+Njob+M+1) == 3, :);
else
    sita_pack = [];
end

for i=1:N
    parent=Parent_population(i,:);
    
% ���ݲ���ѡȡ alpha, peta, sita ��ƥ�쵼��
    alpha = alpha_pack(randi(size(alpha_pack, 1)), :);
    
    if Parent_highest_rank >= 2
        peta = peta_pack(randi(size(peta_pack, 1)), :);
    else
        peta = alpha_pack(randi(size(alpha_pack, 1)), :);
    end
    
    if Parent_highest_rank >= 3
        sita = sita_pack(randi(size(sita_pack, 1)), :);
    else
        sita =alpha_pack(randi(size(alpha_pack, 1)), :);
    end
   
    a=rand;
    if a<1/3
        leader=alpha;
    elseif a<2/3
         leader=peta;
    else
        leader=sita;
    end
    New_Wolf=MOHGWOcross( parent, leader);
%     New_Wolf(1,Njob+1:D+Njob)=Upm1(parent(1,Njob+1:D+Njob),  alpha(1,Njob+1:D+Njob),peta(1,Njob+1:D+Njob),sita(1,Njob+1:D+Njob));
    if rand<PM
        New_Wolf=MOHGWOmutation(New_Wolf);
    end
    New_Wolf=NSGAfitness(New_Wolf); %��Ŀ��������
    ct=ct+1;
    savepop();
    individual(i,:)=New_Wolf;
end