function machine_assignment=Upm1(parent,alpha,peta,sita)    
global ct maxct  D 
kalpha=5;
a=2 ./ (1 + exp(kalpha*1e-4 * (ct  - maxct / 2)));
%  a=2 ./ (1 + exp(k * (ct - maxct / 2)));
  r1=rand(); % r1 is a random number in [0,1]
  r2=rand(); % r2 is a random number in [0,1]
  
  A1=2*a*r1-a; % Equation (3.3)
  C1=2*r2; % Equation (3.4)
  
  D_alpha=abs(C1*alpha-parent); % Equation (3.5)-part 1
  X1=alpha-A1*D_alpha; % Equation (3.6)-part 1
  
  r1=rand();
  r2=rand();
  
  A2=2*a*r1-a; % Equation (3.3)
  C2=2*r2; % Equation (3.4)
  
  D_peta=abs(C2*peta-parent); % Equation (3.5)-part 1
  X2=peta-A2*D_peta; % Equation (3.6)-part 1
  
  r1=rand();
  r2=rand();
  
  A3=2*a*r1-a; % Equation (3.3)
  C3=2*r2; % Equation (3.4)
  
  D_sita=abs(C3*sita-parent); % Equation (3.5)-part 1
  X3=sita-A3*D_sita; % Equation (3.6)-part 1
  
  machine_assignment=round((X1+X2+X3)/3,4);% Equation (3.7)
  
  %�����߽紦��
  for i=1:D
      if machine_assignment(i) > 1 ||  machine_assignment(i) < 0
          machine_assignment(i) = rand();
      end
  end
end
 
 
%  
%  % Return back the search agents that go beyond the boundaries of the search space
%  Flag4ub=Positions(i,:)>ub;
%  Flag4lb=Positions(i,:)<lb;
%  Positions(i,:)=(Positions(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
