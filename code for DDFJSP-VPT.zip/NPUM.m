function P=NPUM(P1)
global D M Njob N ct
P=P1;
miu=0.03;
[alpha,peta,sita]=findleader(P1);
[omiga1,omiga2,omiga3]=findlowest(P1);

X1=alpha(1,Njob+D+1:Njob+D*2);
X2=peta(1,Njob+D+1:Njob+D*2);
X3=sita(1,Njob+D+1:Njob+D*2);

Xw1=omiga1(1,Njob+D+1:Njob+D*2);
Xw2=omiga2(1,Njob+D+1:Njob+D*2);
Xw3=omiga3(1,Njob+D+1:Njob+D*2);
for i=1:N
    S=P1(i,:);
    Snew=S;
    X= S(1,Njob+D+1:Njob+D*2);
    Xbest=(X1+X2+X3)/3;
    Xworst=(Xw1+Xw2+Xw3)/3;
    r1=rand();
    r2=rand();
    Xnew=X+miu*r1*(Xbest-X)+miu*r2*(X-Xworst);
    Snew(1,Njob+D+1:Njob+D*2)=Xnew;
    Snew=MOGWOfitness(Snew);
    flag=zhanyou(Snew,S);
    ct=ct+1;
    savepop();
    if flag==1
        P(i,:)=Snew;
    end
end