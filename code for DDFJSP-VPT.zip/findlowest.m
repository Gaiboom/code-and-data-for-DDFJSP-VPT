function [omiga1,omiga2,omiga3]=findlowest(P1)
global D M Njob
max_rank=max(P1(:,Njob+2*D+M+1));
T1=P1(P1(:,Njob+2*D+1)==max(P1(:,Njob+2*D+1)),:);
T2=P1(P1(:,Njob+2*D+2)==max(P1(:,Njob+2*D+2)),:);
 T1 = sortrows( T1, Njob+2*D+M+2);
  T2 = sortrows( T2, Njob+2*D+M+2);
  omiga1=T1(1,:);
  omiga2=T2(1,:);
  Fn=P1(P1(:,Njob+2*D+M+1)==max_rank,:);
 Fn= sortrows( Fn, Njob+2*D+M+2);
 omiga3=Fn(1,:);
  
end