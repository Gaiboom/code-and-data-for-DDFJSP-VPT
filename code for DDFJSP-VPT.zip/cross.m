function [individual1,individual2]=cross(parent1,parent2)
[child_1,child_2]=NSGAfactory_selection_cross(parent1,parent2);    
[child_3,child_4]=machine_assignment_cross(child_1,child_2);   
[child_5,child_6]=NSGAoperation_sequence_cross(child_3,child_4);          
individual1=child_5;
individual2=child_6;
end