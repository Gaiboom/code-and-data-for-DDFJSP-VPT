b=[2,4,5,6]
for i=b
    cjp=i;
end