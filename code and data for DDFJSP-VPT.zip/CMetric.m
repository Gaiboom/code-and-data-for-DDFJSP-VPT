function C=CMetric(A,B)
sizeB=size(B,1);
sizeA=size(A,1);
count=0;
for i=1:sizeB
    Bnd=B(i,:);
    for j=1:sizeA
        And=A(j,:);
        flag=0;
        if j==56
            cjp=56;
        end
        fitness1=Bnd(1,end-2:end);
        fitness2=And(1,end-2:end);
        ZY=zhanyou1(Bnd,And);
        if ZY==-1
            flag=1;
            break
        end
    end
    if flag==1
       count=count+1;
    end
end
C=count/sizeB;
end