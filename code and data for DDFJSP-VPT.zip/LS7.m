function Snew=LS7(individual)  %%N8 �漰�ؼ����ڲ����Ƴ��ؼ���
global  D M Njob ct Nfactory  MM F_matrix operation_machine  Nmachine MM Job_set
    % N8
    Snew=individual;
    SH=D;
    p_chrom=Snew(1,Njob+D+1:Njob+D*2);
    f_chrom=Snew(1,1:Njob);
    m_chrom=Snew(1,Njob+1:Njob+D);
    N=Njob;
    critical_f=Snew(1,Njob+D*2+M+3);
    s1=p_chrom;
    s2=zeros(1,SH);
    p=zeros(1,N);
    newf=f_chrom;
    s1=p_chrom;
    s2=zeros(1,SH);
    p=zeros(1,N);
    for i=1:SH
        index=find(Job_set==s1(i));
        p(index)=p(index)+1;%��¼�����Ƿ�ӹ���� ���һ�μ�һ
        s2(i)=p(index);%��¼�ӹ������У������Ĵ���
    end
    P1=[];P2=[];IP1=[];IP2=[];
    for i=1:SH
        t1=s1(i);%��¼����ǰ���Ǹ�����
        t2=s2(i);%��¼��ǰ�����Ǽӹ����ڼ���
        index=find(Job_set==t1);
        if f_chrom( index)== critical_f
            P1=[P1 p_chrom(i)];
            IP1=[IP1,i];
        end
    end
    FJ1=[];FJ2=[];
    for i=1:N
        if f_chrom(i)==critical_f
            FJ1=[FJ1 i];
        else
            FJ2=[FJ2 i];
        end
    end

    % CriticalPath �ŵ��ǹؼ�·���ϵ�operator�����е��±�
    % CriticalBlock �ŵ��ǹؼ�·����ÿ�����йؼ�������±�
    % block�ŵ��ǿ�ĸ���
 [CriticalPath,CriticalBlock,block]=FindCriticalPathDFJSP(P1,m_chrom,FJ1,critical_f); %�ؼ�·�����ص�������Ⱦɫ���йؼ�������±�
    
    % Ԥ������ÿ�������ϵĹ����±�
    opcnt = zeros(N, 1);
    machineN=Nmachine(critical_f);
    maidx = cell(machineN, 1);
    for i = 1:SH
        job = p_chrom(i);
        index_job=find(Job_set==job);
        if f_chrom(index_job)~=critical_f
            continue;
        end
        opcnt(index_job) = opcnt(index_job) + 1;
        machine_code=m_chrom(sum(MM(2,1:1:index_job-1))+opcnt(index_job));             %��ǰ����operation_ID��Ӧ�ļӹ�����
        machine_Index=determine_machine( machine_code,size(operation_machine{sum(MM(2,1:index_job-1))+opcnt(index_job),critical_f}(1,:),2));
        machine=operation_machine{sum(MM(2,1:index_job-1))+opcnt(index_job),critical_f}(1,machine_Index);
        maidx{machine} = [maidx{machine} i];
    end
    
    smach = 1:machineN;
    for i = CriticalPath
        for m = smach
            if ismember(i, maidx{m})==1
                rd = randi(2);
                idx = find(maidx{m}==i);
                if length(maidx{m})==1
                    continue;
                end
                if (rd==1 || idx==1) && idx~=length(maidx{m}) % ��Ϊu
                    Index1 = i;
                    Index2 = maidx{m}(ceil(rand*(length(maidx{m})-idx))+idx);
                    b = isInBlock(Index1, Index2);
                    if b~=0 % ˵�������±���b�Ŀ���
                        BL=length(CriticalBlock(b).B);
                        if BL>1
                           % �׹�������ڲ�
                            Index1=1;
                            Index2=ceil(rand*(BL-2))+1;
                            Index1=CriticalBlock(b).B(Index1);
                            Index2=CriticalBlock(b).B(Index2);
                            tmp=P1(Index1);
                            for j=Index1:Index2-1
                                P1(j)=P1(j+1);
                            end
                            P1(Index2)=tmp;

                           % β��������ڲ�
                            Index1=ceil(rand*(BL-2))+1;
                            Index2=BL;
                            Index1=CriticalBlock(b).B(Index1);
                            Index2=CriticalBlock(b).B(Index2);
                            tmp=P1(Index2);
                            for j=Index2:-1:Index1+1
                                P1(j)=P1(j-1);
                            end
                            P1(Index1)=tmp;

                          % �ڲ�����������֮ǰ
                            Index1=1;
                            Index2=ceil(rand*(BL-2))+1;  
                            Index1=CriticalBlock(b).B(Index1);
                            Index2=CriticalBlock(b).B(Index2);
                            tmp=P1(Index2);
                            for j=Index2:-1:Index1+1
                                P1(j)=P1(j-1);
                            end
                            P1(Index1)=tmp;

                          % �ڲ���������β֮��
                            Index1=ceil(rand*(BL-2))+1;
                            Index2=BL;
                            Index1=CriticalBlock(b).B(Index1);
                            Index2=CriticalBlock(b).B(Index2);
                            tmp=P1(Index1);
                            for j=Index1:Index2-1
                                P1(j)=P1(j+1);
                            end
                            P1(Index2)=tmp;
                        end
                    else
                        %                         Index2 = Index2+1;
                        Index1 = find(IP1==Index1);
                        Index2 = find(IP1==Index2);
                        tmp=P1(Index1);
                        for j=Index1:Index2-1
                            P1(j)=P1(j+1);
                        end
                        P1(Index2)=tmp;
                    end
                else % ��Ϊv
                    Index2 = i;
                    Index1 = maidx{m}(ceil(rand*(idx-1)));
                    b = isInBlock(Index1, Index2);
                    if b~=0 % ˵�������±���b�Ŀ���
                        BL=length(CriticalBlock(b).B);
                        if BL>1
                           % �׹�������ڲ�
                            Index1=1;
                            Index2=ceil(rand*(BL-2))+1;
                            Index1=CriticalBlock(b).B(Index1);
                            Index2=CriticalBlock(b).B(Index2);
                            tmp=P1(Index1);
                            for j=Index1:Index2-1
                                P1(j)=P1(j+1);
                            end
                            P1(Index2)=tmp;

                           % β��������ڲ�
                            Index1=ceil(rand*(BL-2))+1;
                            Index2=BL; 
                            Index1=CriticalBlock(b).B(Index1);
                            Index2=CriticalBlock(b).B(Index2);
                            tmp=P1(Index2);
                            for j=Index2:-1:Index1+1
                                P1(j)=P1(j-1);
                            end
                            P1(Index1)=tmp;

                          % �ڲ�����������֮ǰ
                            Index1=1;
                            Index2=ceil(rand*(BL-2))+1;  
                            Index1=CriticalBlock(b).B(Index1);
                            Index2=CriticalBlock(b).B(Index2);
                            tmp=P1(Index2);
                            for j=Index2:-1:Index1+1
                                P1(j)=P1(j-1);
                            end
                            P1(Index1)=tmp;
                            
                            % �ڲ���������β֮��
                            Index1=ceil(rand*(BL-2))+1;
                            Index2=BL;
                            Index1=CriticalBlock(b).B(Index1);
                            Index2=CriticalBlock(b).B(Index2);
                            tmp=P1(Index1);
                            for j=Index1:Index2-1
                                P1(j)=P1(j+1);
                            end
                            P1(Index2)=tmp;
                        end
                    else
                        %                         Index1 = Index1-1;
                        Index1 = find(IP1==Index1);
                        Index2 = find(IP1==Index2);
                        tmp=P1(Index2);
                        for j=Index2:-1:Index1+1
                            P1(j)=P1(j-1);
                        end
                        P1(Index1)=tmp;
                    end
                end 
                smach(smach==m) = [];
                break;
            end
        end
    end
    
newm=m_chrom;

newp=p_chrom;
L=length(IP1);
for i=1:L
  newp(1,IP1(i))=P1(i);  
end
Snew(1,Njob+2*D+1:Njob+D*2+5)=0;
Snew(1,Njob+D+1:Njob+D*2)= newp;
Snew=fitness( Snew);
ct=ct+1;
savepop();
    
    function p = isInBlock(idx1, idx2)
        p = 0;
        for k = 1:block
            B = CriticalBlock(k).B;
            if ismember(idx1,B)==1 && ismember(idx2,B)==1
                p = k;
                break;
            end
        end
    end
end