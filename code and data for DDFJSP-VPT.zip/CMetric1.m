function C=CMetric1(A,B)
sizeB=size(B,1);
sizeA=size(A,1);
count=0;
for i=1:sizeB
    And=A(i,:);
    for j=1:sizeA
        Bnd=B(j,:);
        flag=0;
        ZY=zhanyou1(Bnd,And);
        if ZY==1
            flag=1;
            break
        end
    end
    if flag==1
       count=count+1;
    end
end
C=count/sizeB;
end