function operation_sequence=OSor()
global D par
counter=randperm(D);
operation_sequence=par(:,counter);
end