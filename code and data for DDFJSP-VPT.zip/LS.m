function Snew=LS(individual,k)
if k==1
    Snew=LS1(individual);
elseif k==2
    Snew=LS2(individual);
% elseif k==3
%     Snew=LS3(individual);
elseif k==3
    Snew=LS8(individual);
elseif k==4
    Snew=LS5(individual);
elseif k==5
    Snew=LS6(individual);
else 
    Snew=LS7(individual);
end
end